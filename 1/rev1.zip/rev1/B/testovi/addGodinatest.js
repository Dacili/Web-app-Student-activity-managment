var devices = {
    mobile: {
      deviceName: "mobile",
      size: "480x800"
    },
    desktop: {
      deviceName: "desktop",
      size: "1024x768"
    }
  };
  
  var browsers = {
    firefox: {
        browserName: "firefox"
    }
  };
  
  forAll(devices, function () {
    forAll(browsers, function () {
      test("Test on ${browserName} on ${deviceName}", function (device, browser) {
      var driver = createDriver("http://localhost/addGodina.html", device.size, browser.browserName);
      checkLayout(driver, "addGodinatest.gspec", device.deviceName);
  
      driver.quit();
      });
    }); 
  });